<?=$page->showHeader()?>
<?=$page->showMenu()?>
<?=$page->showUserLogin()?>
<?=$page->showUserRegister()?>
<?=$page->showPage(array("content"))?>
<?=$page->showFooter()?>