<?=$page->showHeader()?>
<div class="header otherheader">
    <a style="padding-left: 22px;" class='big' href='.'><img src="img/firework.png" style="height:85px;display:inline-block;" /></a>
    <a style="padding-left: 22px;display:none;" class='small' href='.'><img src="img/firework.png" style="height:85px;display:inline-block;" /></a>
    <?=$page->showMenu()?>
</div>
<div class='error'><span>Error 404 - <sub>Verifique si el panda travieso no ha hecho de las suyas</sub>
<img style='margin: 0 24%;' src='themes/firework/img/404.jpg' /></span></div>
<?=$page->showFooter()?>