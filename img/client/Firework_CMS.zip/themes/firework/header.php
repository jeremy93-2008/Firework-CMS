<!doctype>
<html>
<head>
    <title><?=$page->fw_title?></title>
    <link rel='stylesheet' href='themes/firework/css/style.css' />
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css' />
    <script type='text/javascript' src='themes/firework/js/script.js'></script>
</head>
<body>
    <div class='wrapper'>