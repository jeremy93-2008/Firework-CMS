<?php
/*
    Fw-Name: Documentation;
    Fw-Description: Manuales para Firework CMS;
    Fw-Date: 19/06/2017;
    Fw-Category: 9;
    Fw-Author: admin,jeremy;
    Fw-Access: 0;
    Fw-Deny: ;
    Fw-Image:img/client/lake.jpg;
*/
?><p><span style="font-family: Arial;">Welcome to the Documentation section of </span><strong><span style="font-family: Arial;">Firework CMS</span></strong><span style="font-family: Arial;">, here you can found a lot of help to understand and create with</span><strong><span style="font-family: Arial;"> Firework CMS</span></strong><span style="font-family: Arial;">. (in Spanish)</span></p>
<p><span style="font-family: Arial;"><img src="img/client/29-actionable-and-insightful-blogging-tips-for-2016.jpg" style="width: 219px; height: 144px;border:solid 2px white;outline:solid 1px lightgray;" /><br /></span></p>
<ul>
  <li><font face="Arial"><i>User's manual:</i></font>
    <ul style="margin-left:25px;">
      <li><font face="Arial"><i><a href="doc/manual.pdf">doc/manual.pdf</a></i></font></li>
    </ul>
  </li>
  <li><font face="Arial"><i>Template Documentation:&nbsp;</i></font>
    <ul style="margin-left:25px;">
      <li><font face="Arial"><i><a href="doc/template_manual.html">doc/template_manual.html</a><br /></i></font></li>
    </ul>
  </li>
  <li><span style="font-family: Arial;">Plugin Documentation:</span>
    <ul style="margin-left:25px;">
      <li><span style="font-family: Arial;"><a href="http://localhost:9000/doc/doc_plugin.html" target="_blank">doc/doc_plugin.html</a><br /></span></li>
    </ul>
  </li>
  <li><span style="font-family: Arial;"><em>JSON Object Documentation</em>:</span>
    <ul style="margin-left:25px;">
      <li><span style="font-family: Arial;"><a href="doc/JSON_doc.html" target="_blank">doc/JSON_doc.html</a></span></li>
    </ul>
  </li>
</ul>
<p>
  <br />
</p>
<p>
  <ul style="margin-left:25px;">
  </ul>
</p>