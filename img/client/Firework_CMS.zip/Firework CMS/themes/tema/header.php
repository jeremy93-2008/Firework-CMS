<!doctype>
<html>
<head>
    <title><?=$page->fw_title?></title>
</head>
<body>