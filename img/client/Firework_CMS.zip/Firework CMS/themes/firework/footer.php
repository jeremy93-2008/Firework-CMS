</div>
<div class='footer'>
    <div class='license'>
        <a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/"><img alt="Licencia de Creative Commons" style="border-width:0" src="https://i.creativecommons.org/l/by-sa/4.0/88x31.png" /></a>
        <p>Author: Jeremy Auvray</p>
        <a href='.?pa=1&ac=4'>With Special Thanks For</a>
    </div>
</div>
</body>
</html>