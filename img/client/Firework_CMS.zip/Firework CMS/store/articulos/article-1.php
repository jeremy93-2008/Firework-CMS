<?php
/*
    Fw-Name: Firework Features;
    Fw-Description: Enumeración de las principales características de Firework;
    Fw-Date: 19/06/2017;
    Fw-Category: 9;
    Fw-Author: admin;
    Fw-Access: 0;
    Fw-Deny: ;
    Fw-Image:img/client/afpgetty-510286731.jpg;
*/
?><span style="font-family: Arial;"><br /></span>
<div style="width:97%;min-height:195px;background:linear-gradient(#EEE,#DDD);margin:0;padding:15px;border:solid 1px lightgray">
  <img src="img/client/29-actionable-and-insightful-blogging-tips-for-2016.jpg" style="width: 280px; height: 185px;border:solid 2px white;outline:solid 1px lightgray;vertical-align:top;float:left;" />&nbsp;
  <p style="display:inline"></p>
  <p style="display:inline"><span style="font-family: Arial;font-size:26px;"><em>Made for Bloggers</em></span></p>
  <p>&nbsp; <span style="font-family: Arial;">Firework CMS has a system of articles and pages <br />&nbsp; that allows you to build your personal corner in a short time. <br />&nbsp; It can also delimit users who have access to these, filtering or categorizing.<br />&nbsp; See more in User's guide:&nbsp;</span></p>
</div>
<br />
<div style="width:97%;min-height:195px;background:linear-gradient(#EEE,#DDD);margin:0;padding:15px;border:solid 1px lightgray">
  <span style="font-family: Arial;font-size:26px;"><em>Made for Designers</em></span>
  <p>&nbsp; <span style="font-family: Arial;float:left">Firework CMS has a system of templates and customization of it&nbsp;<br />that allows you to build your own style in relatively easy<br />For that purpose Firework CMS have templates functions to access easily to it.<br />See more in Template's documentation:&nbsp;</span></p>
  <p><span style="font-family: Arial;float:left"><br /></span></p>
  <img src="img/client/web_design.jpg" style="width: 280px; height: 185px;border:solid 2px white;outline:solid 1px lightgray;vertical-align:top;float:right;margin-top:-75px;" />
</div>
<br />
<div style="width:97%;min-height:195px;background:linear-gradient(#EEE,#DDD);margin:0;padding:15px;border:solid 1px lightgray">
  <img src="img/client/mautic_developer_mautician.jpg" style="width: 280px; height: 185px;border:solid 2px white;outline:solid 1px lightgray;vertical-align:top;float:left;" />&nbsp;
  <p style="display:inline"></p>
  <p style="display:inline"><span style="font-family: Arial;font-size:26px;"><em>Made for Developers</em></span></p>
  <p>&nbsp; <span style="font-family: Arial;">Firework CMS has a system of plugins and API&nbsp;<br />&nbsp; that allows you to build your own Firework oriented to your need. <br />&nbsp; To have full access Firework CMS give you some useful function<br />&nbsp; to connect your plugin to the CMS.<br />&nbsp; See more in Plugin's documentation:&nbsp;<a href="doc/doc_plugin.html" target="_blank">Plugin Documentation</a><br />&nbsp; And/Or JSON Object: <a href="doc/JSON_doc.html" target="_blank">JSON Object Documentation</a></span></p>
</div>
<br />
<br />
<br />