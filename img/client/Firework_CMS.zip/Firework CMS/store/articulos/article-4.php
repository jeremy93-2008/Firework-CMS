<?php
/*
    Fw-Name: Special Thanks For;
    Fw-Description: Special Thanks For;
    Fw-Date: 19/06/2017;
    Fw-Category: 9;
    Fw-Author: admin;
    Fw-Access: 0;
    Fw-Deny: ;
    Fw-Image:img/client/29-actionable-and-insightful-blogging-tips-for-2016.jpg;
*/
?><p>This present entry is to thank all people that supported me, and they did this posible, I never would have been able to do so much without your help, so it's for that than I want to thanks sincerly everyone of you. (The rest is in Spanish)</p>
<p>Agradezco a cada una de las personas que hicieron eso posible, no hace falta nombrarlas, ya se reconocerán por si mismas, el hecho es que fue un proyecto gracioso de realizar, hubo problemas que no me esperaba pero ninguno que fuera demasiado grande tampoco, creo que es posible pensar en este proyecto con una perspectiva de futuro, lo hice <em>Open Source</em> con una licencia <em>Creative Commons</em> para poder tocar el máximo de gente posible con esto, estará también disponible en Github dentro de poco.</p>
<p>También tocaría agradecer a los profesores tanto que me enseñaron en SMR, como en DAW, y eso eee Gracias, no hubiese sido tan sencillo sin vosotros y la institución que os ampara.</p>
<p>Y nada más, podéis comentar cosas si queréis, </p>
<p>Gracias,</p>
<p>Jeremy</p>